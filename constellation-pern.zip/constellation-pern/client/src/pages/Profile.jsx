import React from 'react';
import './Home.css';

const Profile = () => (
  <div className="page-container">
    <h1>Profile</h1>
    <p>This page is under construction.</p>
  </div>
);

export default Profile;
