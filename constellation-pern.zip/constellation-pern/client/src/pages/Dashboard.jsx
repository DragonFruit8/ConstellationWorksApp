import React from 'react';
import './Home.css';

const Dashboard = () => (
  <div className="page-container">
    <h1>Dashboard</h1>
    <p>This page is under construction.</p>
  </div>
);

export default Dashboard;
