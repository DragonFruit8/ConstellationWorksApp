import React from 'react';
import './Home.css';

const MyDonations = () => (
  <div className="page-container">
    <h1>MyDonations</h1>
    <p>This page is under construction.</p>
  </div>
);

export default MyDonations;
