import React from 'react';
import './Home.css';

const ForgotPassword = () => (
  <div className="page-container">
    <h1>ForgotPassword</h1>
    <p>This page is under construction.</p>
  </div>
);

export default ForgotPassword;
