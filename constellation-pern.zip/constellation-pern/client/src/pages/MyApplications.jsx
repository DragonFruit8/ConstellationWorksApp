import React from 'react';
import './Home.css';

const MyApplications = () => (
  <div className="page-container">
    <h1>MyApplications</h1>
    <p>This page is under construction.</p>
  </div>
);

export default MyApplications;
